# DermaLab Benelux — Finance Dashboard

## Deploy to Vercel (5 minutes)

### Option A — Drag & drop (no account needed)
1. Go to https://vercel.com/new
2. Drag this entire `dermalab-dashboard` folder onto the page
3. Click **Deploy**
4. Your dashboard is live at e.g. `dermalab-dashboard.vercel.app`

### Option B — Via GitHub (recommended for easy updates)
1. Create a free account at https://github.com
2. Create a new repository called `dermalab-dashboard`
3. Upload both files (`index.html` and `vercel.json`)
4. Go to https://vercel.com → Import Git Repository → connect your GitHub
5. Select `dermalab-dashboard` → Deploy
6. Every time you update `index.html` in GitHub, Vercel auto-deploys

## Updating data
When you have new Yuki exports, send them to Claude and ask to update the data.
Then replace `index.html` in your GitHub repo — the live URL updates automatically.

## Settings persistence
Use the **Save settings** button in the sidebar to export your customisations
(renamed accounts, categories, budgets) as a JSON file.
Load them back via **Load settings** after any update.
